/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Tables;

import DBConnection.DBConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Order {

    private int id;
    private String RestaurantName;
    private String ProductName;
    private int Quantity;
    private int Price;
    private String AgentName;

    public Order() {
    }

    public void select() {
        try {
            Vector row = new Vector();
            row.setSize(0);

            DBConnection.databaseConnection();

            PreparedStatement preparedStatement = DBConnection.connection.prepareStatement("select id,RestaurantName,ProductName,Quantity,Price,AgentName from orderingsystem.order;");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                String idl = resultSet.getString("id");
                String RestaurantName = resultSet.getString("RestaurantName");
                String ProductName = resultSet.getString("ProductName");
                int Quantity = resultSet.getInt("Quantity");
                int Price = resultSet.getInt("Price");
                String AgentName = resultSet.getString("AgentName");

                String addressl = resultSet.getString("address");
                Vector column = new Vector();
                column.add(idl);
                column.add(RestaurantName);
                column.add(ProductName);
                column.add(Quantity);
                column.add(Price);
                column.add(AgentName);
                row.add(column);
            }
            resultSet.close();
            preparedStatement.close();

            for (int i = 0; i < row.size(); i++) {
                System.out.println(row.get(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void insert() {
        try {
            DBConnection.databaseConnection();

            PreparedStatement preparedStatement = DBConnection.connection.prepareStatement("insert into orderingsystem.order(id,RestaurantName,ProductName,Quantity,Price,AgentName) values (?,?,?,?,?,?)");
            preparedStatement.setInt(1, getId());
            preparedStatement.setString(2, getRestaurantName());
            preparedStatement.setString(3, getProductName());
            preparedStatement.setInt(4, getQuantity());
            preparedStatement.setInt(5, getPrice());
            preparedStatement.setString(6, getAgentName());

            preparedStatement.execute();

            preparedStatement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update() {
        try {
            DBConnection.databaseConnection();
            PreparedStatement preparedStatement = DBConnection.connection.prepareStatement("update orderingsystem.order set RestaurantName= ?,ProductName=?,Quantity=?,Price=?,AgentName=? where id = ?");

            preparedStatement.setString(1, getRestaurantName());
            preparedStatement.setString(2, getProductName());
            preparedStatement.setInt(3, getQuantity());
            preparedStatement.setInt(4, getPrice());
            preparedStatement.setString(5, getAgentName());
            preparedStatement.setInt(6, getId());
            preparedStatement.execute();
            preparedStatement.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void delete() {
        try {
            DBConnection.databaseConnection();
            PreparedStatement statement = DBConnection.connection.prepareStatement("delete from  orderingsystem.order"
                    + "where id = ?");
            statement.setInt(1, getId());
            statement.execute();
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the RestaurantName
     */
    public String getRestaurantName() {
        return RestaurantName;
    }

    /**
     * @param RestaurantName the RestaurantName to set
     */
    public void setRestaurantName(String RestaurantName) {
        this.RestaurantName = RestaurantName;
    }

    /**
     * @return the ProductName
     */
    public String getProductName() {
        return ProductName;
    }

    /**
     * @param ProductName the ProductName to set
     */
    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    /**
     * @return the Quantity
     */
    public int getQuantity() {
        return Quantity;
    }

    /**
     * @param Quantity the Quantity to set
     */
    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    /**
     * @return the Price
     */
    public int getPrice() {
        return Price;
    }

    /**
     * @param Price the Price to set
     */
    public void setPrice(int Price) {
        this.Price = Price;
    }

    /**
     * @return the AgentName
     */
    public String getAgentName() {
        return AgentName;
    }

    /**
     * @param AgentName the AgentName to set
     */
    public void setAgentName(String AgentName) {
        this.AgentName = AgentName;
    }
}
